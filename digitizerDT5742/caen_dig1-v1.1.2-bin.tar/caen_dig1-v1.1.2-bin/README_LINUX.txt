-----------------------------------------------------------------------------

                    --- CAEN SpA - Software Division ---

-----------------------------------------------------------------------------

    CAEN Dig1 Library

    Readme for Linux.

-----------------------------------------------------------------------------


*****************************************************************************
PUBLIC BETA VERSION Disclaimer:

WEB PUBLISHED BETA SOFTWARE VERSIONS MAY CONTAIN DEFECTS AS THEY ARE PRIMARILY
INTENDED FOR BETA TESTING PURPOSES AND BUG IDENTIFICATION.
CAEN DOES NOT GUARANTEE FULL FUNCTIONALITIY AND STABILITY OF BETA SOFTWARE,
AND DENIES ANY RESPONSIBILITY FOR REAL OR POTENTIAL, DIRECT OR INDIRECT DAMAGES
DUE TO THE USE OF THIS SOFTWARE. THE USER MUST BE CONSCIOUS THAT BETA SOFTWARE
IS PROVIDED "AS IS" AND HE MUST BE CONSIDERED THE ONLY RESPONSIBLE FOR ITS USAGE.

PLEASE SEND YOUR FEEDBACK OR SIGNAL BUGS TO OUR SUPPORT:
https://www.caen.it/support-services/support-form/
*****************************************************************************


Copyright notice
----------------

Copyright (C) 2020-2023 CAEN SpA

The CAEN Dig1 Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The CAEN Dig1 Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
for more details.

You should have received a copy of the GNU Lesser General Public License along
with the CAEN Dig1 Library; if not, see https://www.gnu.org/licenses/.

The license applies to the CAEN Dig1 Library source as a whole, though individual
source files can have a different license which is required to be compatible
with the GNU Lesser General Public Library, version 3. You may find more details
on the Credits section of this file.


Support
-------

For technical support, go to https://www.caen.it/mycaen/support/ (login and
MyCAEN+ account required).

If you don't have an account or want to update your old one, find the instructions
at https://www.caen.it/support-services/getting-started-with-mycaen-portal/.


Content
-------

Library            : Binary shared libraries are provided in this package. Install instructions can be found on INSTALL.
Demo               : Demo projects with Makefile are deployed with the binary package. Deploy information can be found on INSTALL.


Prerequisites
-------------

- See INSTALL.


Credits
-------

The CAEN Dig1 Library is made possible by other third part open source software.

JSON for Modern C++:
- Website: https://github.com/nlohmann/json
- License: MIT license
- Copyright: Copyright 2013-2022 Niels Lohmann

spdlog, a very fast, header-only/compiled, C++ logging library:
- Website: https://github.com/gabime/spdlog
- License: MIT license
- Copyright: Copyright 2016 Gabi Melman

TinyCThread, a minimalist, portable, threading library for C:
- Website: https://tinycthread.github.io
- License: zlib License
- Copyright: Copyright 2012 Marcus Geelnard
- Copyright: Copyright 2013-2016 Evan Nemerson
